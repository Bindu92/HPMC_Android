package com.hpmc.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.hmpc.dto.BaseDTO;
import com.hmpc.files.service.FileService;


/**
 * @author Prakat-L-042
 *
 */
@RestController
@RequestMapping(value={"/files"})
public class FileController {

	@Autowired
	FileService fileServiceImpl;

	private static final Logger logger = LogManager.getLogger(FileController.class);	

	/**
	 * This method is for upload the files into the directory bases on file names.  
	 * @param multipartFile
	 * @return {@link BaseDTO}
	 */
	@RequestMapping(method = RequestMethod.POST, value="/uploadFile", headers="Accept=application/json")
	public ResponseEntity<BaseDTO> saveFilesIntoDirectory(@RequestParam("user-file") List<MultipartFile> multipartFile)  {
		logger.info("==>> Enter into FileController inside saveFilesIntoDirectory  <<== START ::"+multipartFile.size());

		BaseDTO responseDTO=new BaseDTO();
		responseDTO= fileServiceImpl.saveFilesIntoDirectory(multipartFile);
		logger.info("==>> Enter into FileController inside saveFilesIntoDirectory <<== End ::"+responseDTO);
		return new ResponseEntity<BaseDTO>(responseDTO,HttpStatus.OK);
	}

	/**
	 * This method is for getting the all file names from the directory
	 * @return {@link BaseDTO}
	 */
	@RequestMapping(value="/downloadAll",method = RequestMethod.GET,headers="Accept=application/json")
	public ResponseEntity<BaseDTO> downloadAllFiles(){
		BaseDTO responseDTO=new BaseDTO();
		responseDTO= fileServiceImpl.loadFileNames();
		return new ResponseEntity<BaseDTO>(responseDTO,HttpStatus.OK);
	}



	/**
	 *  This method for download the file from directory by fileName
	 * @param fileName
	 * @param request
	 * @return {@link Resource}
	 */
	@RequestMapping(value="/downloadFileByName/{fileName:.+}", method = RequestMethod.GET)
	public ResponseEntity<Resource> loadFileAsResourceByFileName(@PathVariable String fileName, HttpServletRequest request){
		logger.info("==>> Enter into FileController inside downkiadFileByFileName <<==START"+fileName);

		System.out.println("Enter into FileController inside downkiadFileByFileName <<==START"+fileName);
		ResponseEntity<Resource> response=null;
		Resource resource =null;
		resource = fileServiceImpl.loadFileAsResourceByFileName(fileName);
		try {
			if(resource.contentLength()==0){
				response=new ResponseEntity<Resource>(resource,HttpStatus.NOT_FOUND);
			}else{
				response=new ResponseEntity<Resource>(resource,HttpStatus.OK);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		logger.info("==>> Enter into FileController inside downkiadFileByFileName <<==START"+resource.getFilename());
		System.out.println("Enter into FileController inside downkiadFileByFileName <<==START"+resource.getFilename());

		return response;		
	}


}
