package com.hpmc.startapp;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.hmpc.dto.BaseDTO;
import com.hpmc.portal.pos.webservice.service.PosDeviceDetailsService;

@Component
public class ScheduledTasks {

	private static final Logger logger = LoggerFactory.getLogger(ScheduledTasks.class);

	@Autowired
	PosDeviceDetailsService posDeviceDetailsServiceImpl;

	/**
	 * This method run everyday at 9PM for load all file from directory to database.
	 * 
	 */
	@Scheduled(cron = "0 0 21 * * ?")
	public void scheduleTaskWithCronExpression() {
		logger.info("===>> Cron Task :: Execution Start Time <<=== ::"+new Date());
		BaseDTO reponseDTO=new BaseDTO();

		reponseDTO= posDeviceDetailsServiceImpl.savePosSaleDetailsCSVFiles();
		logger.info(" ==>> hpmc_pos_sale_details table ::"+reponseDTO.getMessage());

		reponseDTO=posDeviceDetailsServiceImpl.savePosSaleItemDetailsCSVFiles();
		logger.info(" ==>> hpmc_pos_sale_details table ::"+reponseDTO.getMessage());

		reponseDTO=posDeviceDetailsServiceImpl.savePosMisPurchaseOrderDetailsCSVFiles();
		logger.info(" ==>> hpmc_pos_mis_purchase_order_details table ::"+reponseDTO.getMessage());

		logger.info("===>> Cron Task :: Execution End Time <<=== ::"+new Date());

	}


}