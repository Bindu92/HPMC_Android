package com.hpmc.startapp;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
@SpringBootApplication()
@RestController
@EnableScheduling
@ComponentScan("com")
public class SpringBootWebApplication extends SpringBootServletInitializer {

	private static final Logger logger = LogManager.getLogger(SpringBootWebApplication.class);	

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(SpringBootWebApplication.class);
	}

	public static void main(String[] args) throws Exception {
		logger.info("===>>Enter into SpringBoot application inside Run method<<===START");
		SpringApplication.run(SpringBootWebApplication.class, args).setId("");
		logger.info("===>>Enter into SpringBoot application inside Run method<<===END");
	}

	@GetMapping("/welcome")
	public String hello() {
		return "Welcome to HPMC Server Application......";
	}

}