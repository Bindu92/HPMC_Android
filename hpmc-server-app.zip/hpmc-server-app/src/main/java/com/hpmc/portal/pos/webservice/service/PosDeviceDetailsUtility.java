package com.hpmc.portal.pos.webservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hpmc.portal.pos.webservice.dao.PosDeviceDetailsDAO;

/**
 * @author Prakat-L-042
 *
 */
@Component
public class PosDeviceDetailsUtility {
	
	
	@Autowired
	PosDeviceDetailsDAO posDeviceDetailsDAOImpl;
	
	
	/**
	 * This method for generate new PosSequencePattern value. 
	 * @return new PosSequencePattern code
	 */
	public String getPosCodeSequence(){
		Integer availablePatternLength=posDeviceDetailsDAOImpl.countNoOfPosCodeSeuence();
		availablePatternLength++;
		int Base = 26;
		String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String newPatternName = "";

		while (availablePatternLength > 0) {
			int position = availablePatternLength % Base;
			newPatternName  = (position == 0 ? 'Z' : chars.charAt(position > 0 ? position - 1 : 0)) + newPatternName ;
			availablePatternLength = (availablePatternLength - 1) / Base;
		}
		return newPatternName;
	}
	
	/**
	 * This method for generate new PosKeyStartRange. 
	 * @return new PosKeyStartRange
	 */
	public Long getPosKeyStartRange(){
		Long startValue;
		List<Object> listOfPosKeyStartRange=posDeviceDetailsDAOImpl.getListOfPosKeyStartRange();
		if(listOfPosKeyStartRange.size()==0){
			startValue=(long)100000001;
		}else{
			Long l=(Long) listOfPosKeyStartRange.get(listOfPosKeyStartRange.size()-1);
			startValue=l+100000000;
		}
		return startValue;		
	}
	
	/**
	 * This method for generate new PosKeyEndRange. 
	 * @return new PosKeyEndRange value
	 */
	public Long getPosKeyEndRange(){
		Long endValue;
		List<Object> listOfPosKeyEndRange=posDeviceDetailsDAOImpl.getListOfPosKeyEndRange();
		if(listOfPosKeyEndRange.size()==0){
			endValue=(long)199999999;
		}else{
			Long l=(Long) listOfPosKeyEndRange.get(listOfPosKeyEndRange.size()-1);
			endValue=l+100000000;
		}
		return endValue;		
	}
	
	
	
}
