package com.hpmc.portal.pos.webservice.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Prakat-L-042
 *
 */
@Entity
@Table(name="hpmc_pos_device_details")
public class PosDeviceDetails implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="POS_DEVICE_ID")
	private Long posDeviceDetailsId;

	@Column(name="POS_SERIAL_NUM")
	private String  posSerialNumber;

	@Column(name="POS_CODE")
	private String posCode;

	@Column(name="POS_KEY_RANGE_START")
	private Long  posKeyRangeStart;

	@Column(name="POS_KEY_RANGE_END")
	private Long  posKeyRangeEnd;

	@Override
	public String toString() {
		return "PosDeviceDetails [posDeviceDetailsId=" + posDeviceDetailsId
				+ ", posSerialNumber=" + posSerialNumber + ", posCode="
				+ posCode + ", posKeyRangeStart=" + posKeyRangeStart
				+ ", posKeyRangeEnd=" + posKeyRangeEnd + "]";
	}

	public Long getPosDeviceDetailsId() {
		return posDeviceDetailsId;
	}

	public void setPosDeviceDetailsId(Long posDeviceDetailsId) {
		this.posDeviceDetailsId = posDeviceDetailsId;
	}

	public String getPosSerialNumber() {
		return posSerialNumber;
	}

	public void setPosSerialNumber(String posSerialNumber) {
		this.posSerialNumber = posSerialNumber;
	}

	public String getPosCode() {
		return posCode;
	}

	public void setPosCode(String posCode) {
		this.posCode = posCode;
	}

	public Long getPosKeyRangeStart() {
		return posKeyRangeStart;
	}

	public void setPosKeyRangeStart(Long posKeyRangeStart) {
		this.posKeyRangeStart = posKeyRangeStart;
	}

	public Long getPosKeyRangeEnd() {
		return posKeyRangeEnd;
	}

	public void setPosKeyRangeEnd(Long posKeyRangeEnd) {
		this.posKeyRangeEnd = posKeyRangeEnd;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((posCode == null) ? 0 : posCode.hashCode());
		result = prime
				* result
				+ ((posDeviceDetailsId == null) ? 0 : posDeviceDetailsId
						.hashCode());
		result = prime * result
				+ ((posKeyRangeEnd == null) ? 0 : posKeyRangeEnd.hashCode());
		result = prime
				* result
				+ ((posKeyRangeStart == null) ? 0 : posKeyRangeStart.hashCode());
		result = prime * result
				+ ((posSerialNumber == null) ? 0 : posSerialNumber.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PosDeviceDetails other = (PosDeviceDetails) obj;
		if (posCode == null) {
			if (other.posCode != null)
				return false;
		} else if (!posCode.equals(other.posCode))
			return false;
		if (posDeviceDetailsId == null) {
			if (other.posDeviceDetailsId != null)
				return false;
		} else if (!posDeviceDetailsId.equals(other.posDeviceDetailsId))
			return false;
		if (posKeyRangeEnd == null) {
			if (other.posKeyRangeEnd != null)
				return false;
		} else if (!posKeyRangeEnd.equals(other.posKeyRangeEnd))
			return false;
		if (posKeyRangeStart == null) {
			if (other.posKeyRangeStart != null)
				return false;
		} else if (!posKeyRangeStart.equals(other.posKeyRangeStart))
			return false;
		if (posSerialNumber == null) {
			if (other.posSerialNumber != null)
				return false;
		} else if (!posSerialNumber.equals(other.posSerialNumber))
			return false;
		return true;
	}
}