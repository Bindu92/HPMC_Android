package com.hpmc.portal.pos.webservice.dao;

import java.util.List;

import com.hmpc.dto.BaseDTO;
import com.hmpc.dto.PosMisPurchaseOrderDetails;
import com.hmpc.dto.PosSaleDetails;
import com.hmpc.dto.PosSaleItemDetails;
import com.hpmc.portal.pos.webservice.bean.PosDeviceDetails;

public interface PosDeviceDetailsDAO {
	
	public BaseDTO savePosDeviceDetailsBySerialNumber(PosDeviceDetails posDeviceDetails);
	
	public Integer  countNoOfPosCodeSeuence();
	
	public List<Object> getListOfPosKeyStartRange();
	
	public List<Object> getListOfPosKeyEndRange();
	
	public Boolean serachPosDevcieDetailsByPosNumber(String posSerialNumber);
	
	public Boolean savePosSaleDetails(PosSaleDetails posSaleDetails);
	
	public Boolean savePosSaleItemDetails(PosSaleItemDetails posSaleItemDetails);
	
	public Boolean savePosMisPurchaseOrderDetails(PosMisPurchaseOrderDetails posMisPurchaseOrderDetails);
	
	

	
}
