package com.hpmc.portal.pos.webservice.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.hmpc.dto.BaseDTO;
import com.hpmc.portal.pos.webservice.service.PosDeviceDetailsService;


/**
 * @author Prakat-L-042
 *
 */
@RestController
@RequestMapping(value={"/posDeviceDetails"})
public class PosDeviceDetailsController {

	private static final Logger logger = LogManager.getLogger(PosDeviceDetailsController.class);	

	@Autowired
	PosDeviceDetailsService posDeviceDetailsService;


	/**
	 * This method for save pos device details into DB.
	 * @param posSerialNumber
	 * @param request
	 * @return {@link BaseDTO}
	 */
	@RequestMapping(value="/savePosDeviceDetailsBySerialNumber/{posSerialNumber:.+}",method=RequestMethod.POST,headers="Accept=application/json")
	public ResponseEntity<BaseDTO> savePosDeviceDetailsBySerialNumber(@PathVariable String posSerialNumber, HttpServletRequest request){
		BaseDTO responseDTO=new BaseDTO();
		logger.info("==>>Enter into PosDeviceDetailsController inside savePosDeviceDetailsBySerialNumber <<==START"+posSerialNumber);
		responseDTO=posDeviceDetailsService.savePosDeviceDetailsBySerialNumber(posSerialNumber);
		logger.info("==>>Enter into PosDeviceDetailsController inside savePosDeviceDetailsBySerialNumber <<==END"+responseDTO);

		return new ResponseEntity<BaseDTO>(responseDTO,HttpStatus.OK);
	}

}
