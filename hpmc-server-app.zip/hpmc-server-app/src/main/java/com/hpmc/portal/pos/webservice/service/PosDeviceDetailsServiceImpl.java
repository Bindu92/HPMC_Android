package com.hpmc.portal.pos.webservice.service;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map.Entry;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hmpc.dto.BaseDTO;
import com.hmpc.dto.PosMisPurchaseOrderDetails;
import com.hmpc.dto.PosSaleDetails;
import com.hmpc.dto.PosSaleItemDetails;
import com.hmpc.utility.ReadCSVFileIntoMap;
import com.hpmc.errorcodes.ErrorCodes;
import com.hpmc.portal.pos.webservice.bean.PosDeviceDetails;
import com.hpmc.portal.pos.webservice.dao.PosDeviceDetailsDAO;

/**
 * @author Prakat-L-042
 *
 */
@Service
@Transactional
public class PosDeviceDetailsServiceImpl implements PosDeviceDetailsService{

	private static final Logger logger = LogManager.getLogger(PosDeviceDetailsServiceImpl.class);	


	@Autowired
	PosDeviceDetailsDAO posDeviceDetailsDAOImpl;

	@Autowired
	PosDeviceDetailsUtility posDeviceDetailsUtility;

	
	@Autowired
	ReadCSVFileIntoMap readCSVFileIntoMap;


	/**
	 * This method for save pos device details into DB.
	 * @param posSerialNumber
	 * @return {@link BaseDTO}
	 */	
	@Override
	public BaseDTO savePosDeviceDetailsBySerialNumber(String posSerialNumber) {
		BaseDTO responseDTO=new BaseDTO();
		String posCode="";
		Long posKeyRangeStart;
		Long posKeyRangeEnd;
		try{
			logger.info("==>> Enter into PosDeviceDetailsServiceImpl inside savePosDeviceDetailsBySerialNumber <<==START ::"+posSerialNumber);

			/*Check PosSerialNumber is exist*/
			Boolean isAvailabale=posDeviceDetailsDAOImpl.serachPosDevcieDetailsByPosNumber(posSerialNumber);
			if(isAvailabale){
				responseDTO.setStatusCode(ErrorCodes.POS_SERIAL_EXIST.getCode());
				responseDTO.setMessage("Failure");
				logger.warn("==>> Error occured in savePosDeviceDetailsBySerialNumber <<== ::"+responseDTO.getDescription());
			}else{

				/*get new posCode from PosDeviceDetailsUtility class*/
				posCode=posDeviceDetailsUtility.getPosCodeSequence();

				/*get new posCode from PosDeviceDetailsUtility class*/
				posKeyRangeStart=posDeviceDetailsUtility.getPosKeyStartRange();


				/*get new posCode from PosDeviceDetailsUtility class*/
				posKeyRangeEnd=posDeviceDetailsUtility.getPosKeyEndRange();

				PosDeviceDetails posDeviceDetails=new PosDeviceDetails(); 
				posDeviceDetails.setPosSerialNumber(posSerialNumber);
				posDeviceDetails.setPosCode(posCode);
				posDeviceDetails.setPosKeyRangeStart(posKeyRangeStart);
				posDeviceDetails.setPosKeyRangeEnd(posKeyRangeEnd);
				responseDTO=posDeviceDetailsDAOImpl.savePosDeviceDetailsBySerialNumber(posDeviceDetails);
			}
		}
		catch(Exception e){
			responseDTO.setStatusCode(ErrorCodes.INTERNAL_SERVER_ERROR.getCode());
			responseDTO.setMessage("Failure");
			logger.error("==>> Exception occured in PosDeviceDetailsServiceImpl inside savePosDeviceDetailsBySerialNumber <<=="+e.getMessage());
		}
		logger.info("==>> Enter into PosDeviceDetailsServiceImpl inside savePosDeviceDetailsBySerialNumber <<==END ::"+responseDTO);
		return responseDTO;
	}



	/**
	 * This method will read all hpmc_pos_sale_item_details_ files and save into DB.
	 * @return {@link BaseDTO}
	 */
	@Override
	public BaseDTO savePosSaleDetailsCSVFiles(){
		BaseDTO responseDTO=new BaseDTO();
		try{
			logger.info("==>> Enter into PosDeviceDetailsServiceImpl inside savePosSaleDetailsCSVFiles <<== START");
			final String DOWNLOAD_FILES_DIRECTORY="C:\\HPMC_POS_Files\\Upload\\KIOSK Sales Shop\\";
			File[] files=new File(DOWNLOAD_FILES_DIRECTORY).listFiles();
			if(files.length!=0){
				for (File file : files) {
					if (file.isFile()) {
						if(file.getName().contains("hpmc_pos_sale_details")){
							LinkedHashMap<Integer,ArrayList<String>> fileContent=readCSVFileIntoMap.readCSVFile(file);
							saveFileIntoPosSaleDetails(fileContent,file.getName());
						}
					}
				}
				responseDTO.setMessage(" Files saved to hpmc_pos_sale_details table");
			}else{
				responseDTO.setMessage("Folder is Empty");
			}
		}catch(Exception e){
			logger.error("==>> Exception occured PosDeviceDetailsServiceImpl inside savePosSaleDetailsCSVFiles <<== ::"+e.getMessage());
		}
		logger.info("==>> Enter into PosDeviceDetailsSer viceImpl inside savePosSaleDetailsCSVFiles <<== END");
		return responseDTO;
	}




	/**
	 * This method will read all hpmc_pos_sale_item_details_ files and save into DB.
	 * @return {@link BaseDTO}
	 */
	@Override
	public BaseDTO savePosSaleItemDetailsCSVFiles(){
		BaseDTO responseDTO=new BaseDTO();
		try{
			logger.info("==>> Enter into PosDeviceDetailsServiceImpl inside savePosSaleItemDetailsCSVFiles <<== START");

			final String DOWNLOAD_FILES_DIRECTORY="C:\\HPMC_POS_Files\\Upload\\KIOSK Sales Shop\\";
			File[] files=new File(DOWNLOAD_FILES_DIRECTORY).listFiles();

			if(files.length!=0){
				for (File file : files) {
					if (file.isFile()) {
						if(file.getName().contains("hpmc_pos_sale_item_details")){
							LinkedHashMap<Integer,ArrayList<String>> fileContent=readCSVFileIntoMap.readCSVFile(file);
							saveFileIntoPosSaleItemDetails(fileContent,file.getName());
						}
					}
					responseDTO.setMessage(" Files saved to hpmc_pos_sale_item_details table");
				}
			}else{
				responseDTO.setMessage("Folder is Empty");
			}
		}catch(Exception e){
			logger.error("==>> Exception occured PosDeviceDetailsServiceImpl inside savePosSaleItemDetailsCSVFiles <<== ::"+e.getMessage());
		}
		logger.info("==>> Enter into PosDeviceDetailsServiceImpl inside savePosSaleItemDetailsCSVFiles <<== END");

		return responseDTO;
	}

	/**
	 * This method will read all hpmc_pos_sale_item_details_ files and save into DB.
	 * @return {@link BaseDTO}
	 */
	@Override
	public BaseDTO savePosMisPurchaseOrderDetailsCSVFiles() {
		BaseDTO responseDTO=new BaseDTO();
		try{
			logger.info("==>> Enter into PosDeviceDetailsServiceImpl inside savePosSaleItemDetailsCSVFiles <<== START");

			final String DOWNLOAD_FILES_DIRECTORY="C:\\HPMC_POS_Files\\Upload\\MIS Purchase\\";
			File[] files=new File(DOWNLOAD_FILES_DIRECTORY).listFiles();
			if(files.length!=0){
				for (File file : files) {
					if (file.isFile()) {
						if(file.getName().contains("hpmc_pos_mis_purchase_order")){
							LinkedHashMap<Integer,ArrayList<String>> fileContent=readCSVFileIntoMap.readCSVFile(file);
							saveFileIntoPosMisPurchaseOrderDetails(fileContent,file.getName());					}
					}
				}
				responseDTO.setMessage(" Files saved to hpmc_pos_mis_purchase_order_details table");
			}else{
				responseDTO.setMessage("Folder is Empty");
			}

		}catch(Exception e){
			logger.error("==>> Exception occured PosDeviceDetailsServiceImpl inside savePosMisPurchaseOrderDetailsCSVFiles <<== ::"+e.getMessage());
		}
		logger.info("==>> Enter into PosDeviceDetailsServiceImpl inside savePosSaleItemDetailsCSVFiles <<== END");
		return responseDTO;
	}


	public  boolean saveFileIntoPosMisPurchaseOrderDetails(LinkedHashMap<Integer,ArrayList<String>> csvFileMap,String fileName){
		Boolean  isAvailable=false;
		Iterator<Entry<Integer, ArrayList<String>>> itr = csvFileMap.entrySet().iterator();
		try{
			while(itr.hasNext()){
				ArrayList<String> al=new ArrayList<String>();
				Entry<Integer, ArrayList<String>> entry = itr.next();
				al.addAll(entry.getValue());
				PosMisPurchaseOrderDetails posMisPurchaseOrderDetails=new PosMisPurchaseOrderDetails();
				for (int i = 0; i < al.size(); i++) {
					if(i==0){
						posMisPurchaseOrderDetails.setPurchaseOrderId(Long.parseLong(al.get(i).trim()));
					}
					if(i==1){
						posMisPurchaseOrderDetails.setGrSlipNo(al.get(i).trim());
					}if(i==2){
						posMisPurchaseOrderDetails.setVendorCode(Long.parseLong(al.get(i).trim()));
					}if(i==3){
						posMisPurchaseOrderDetails.setPurchaseOrderNo(Long.parseLong(al.get(i).trim()));
					}if(i==4){
						posMisPurchaseOrderDetails.setLineItem(Long.parseLong(al.get(i).trim()));
					}if(i==5){
						posMisPurchaseOrderDetails.setPlantCode(al.get(i).trim());
					}if(i==6){
						posMisPurchaseOrderDetails.setStorageLocation(al.get(i).trim());
					}if(i==7){
						posMisPurchaseOrderDetails.setNetWeight(Double.parseDouble(al.get(i).trim()));
					}if(i==8){
						posMisPurchaseOrderDetails.setGrossWeight(Double.parseDouble(al.get(i).trim()));
					}if(i==9){
						posMisPurchaseOrderDetails.setReceivedNumOfBag(Long.parseLong(al.get(i).trim()));
					}if(i==10){
						posMisPurchaseOrderDetails.setTotalAmount(Double.parseDouble(al.get(i).trim()));
					}if(i==11){
						StringBuffer sb=new StringBuffer(al.get(i).trim());
						sb.replace(4, 5, "/");
						sb.replace(7, 8, "/");
						sb.replace(13, 14, ":");
						sb.replace(16, 17, ":");

						SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
						String s=sb.toString();
						Date date = formatter.parse(s);
						posMisPurchaseOrderDetails.setReceiptDate(date);
					}if(i==12){
						posMisPurchaseOrderDetails.setSapStatus(Long.parseLong(al.get(i).trim()));
					}	
				}
				posDeviceDetailsDAOImpl.savePosMisPurchaseOrderDetails(posMisPurchaseOrderDetails);
			}
		}catch(Exception e){
			logger.error("==>> Exception occured in PosDeviceDetailsServiceImpl inside saveFileIntoPosMisPurchaseOrderDetails <<== ::"+e.getMessage());
		}
		return isAvailable;
	}



	public  boolean saveFileIntoPosSaleDetails(LinkedHashMap<Integer,ArrayList<String>> csvFileMap,String fileName){
		Boolean  isSaved=false;
		Iterator<Entry<Integer, ArrayList<String>>> itr = csvFileMap.entrySet().iterator();
		try{
			while(itr.hasNext()){
				ArrayList<String> al=new ArrayList<String>();
				Entry<Integer, ArrayList<String>> entry = itr.next();
				al.addAll(entry.getValue());
				PosSaleDetails posSaleDetails=new PosSaleDetails();
				try{
					for (int i = 0; i < al.size(); i++) {
						if(i==0){
							posSaleDetails.setPosSaleId(Long.parseLong(al.get(i).trim()));
						}
						if(i==1){
							posSaleDetails.setShopId(Long.parseLong(al.get(i).trim()));
						}if(i==2){
							posSaleDetails.setSaleType(al.get(i).trim());
						}if(i==3){
							posSaleDetails.setCustomerName(al.get(i).trim());
						}if(i==4){
							StringBuffer sb=new StringBuffer(al.get(i).trim());
							sb.replace(4, 5, "/");
							sb.replace(7, 8, "/");
							sb.replace(13, 14, ":");
							sb.replace(16, 17, ":");
							SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
							String s=sb.toString();
							Date date = formatter.parse(s);
							posSaleDetails.setDate(date);
						}if(i==5){
							posSaleDetails.setSapStatus(Long.parseLong(al.get(i).trim()));
						}	
					}
				}catch(Exception e){
				}
				isSaved=posDeviceDetailsDAOImpl.savePosSaleDetails(posSaleDetails);
			}

		}catch(Exception e){
			logger.error("==>> Exception occured in PosDeviceDetailsServiceImpl inside saveFileIntoPosSaleDetails <<==  End ::"+e.getMessage());
		}
		return isSaved;
	}

	public  boolean saveFileIntoPosSaleItemDetails(LinkedHashMap<Integer,ArrayList<String>> csvFileMap,String fileName){
		Boolean  isAvailable=false;
		Iterator<Entry<Integer, ArrayList<String>>> itr = csvFileMap.entrySet().iterator();
		while(itr.hasNext()){
			ArrayList<String> al=new ArrayList<String>();
			Entry<Integer, ArrayList<String>> entry = itr.next();
			al.addAll(entry.getValue());
			PosSaleItemDetails posSaleDetails=new PosSaleItemDetails();
			try{
				for (int i = 0; i < al.size(); i++) {
					if(i==0){
						posSaleDetails.setPosSaleItemId(Long.parseLong(al.get(i).trim()));
					}
					if(i==1){
						posSaleDetails.setPosSaleId(Long.parseLong(al.get(i).trim()));
					}if(i==2){
						posSaleDetails.setSaleItemId(Long.parseLong(al.get(i).trim()));
					}if(i==3){
						posSaleDetails.setQuantity(Long.parseLong(al.get(i).trim()));
					}if(i==4){
						posSaleDetails.setUnitOfMeasurement(al.get(i).trim());
					}if(i==5){
						posSaleDetails.setCgstAmount(Double.parseDouble(al.get(i).trim()));
					}if(i==6){
						posSaleDetails.setSgstAmount(Double.parseDouble(al.get(i).trim()));
					}if(i==7){
						posSaleDetails.setTotalAmount(Double.parseDouble(al.get(i).trim()));
					}if(i==8)
						posSaleDetails.setSapStatus(Long.parseLong(al.get(i).trim()));
				}
			}catch(Exception e){
				logger.error("==>> Exception occured in PosDeviceDetailsServiceImpl inside saveFileIntoPosSaleItemDetails <<== End ::"+e.getMessage());
			}
			posDeviceDetailsDAOImpl.savePosSaleItemDetails(posSaleDetails);
		}
		return isAvailable;
	}


}
