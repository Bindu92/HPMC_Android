package com.hpmc.portal.pos.webservice.dao;

import java.io.Serializable;
import java.util.List;

import javax.persistence.EntityExistsException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Repository;

import com.hmpc.dto.BaseDTO;
import com.hmpc.dto.PosMisPurchaseOrderDetails;
import com.hmpc.dto.PosSaleDetails;
import com.hmpc.dto.PosSaleItemDetails;
import com.hpmc.errorcodes.ErrorCodes;
import com.hpmc.errorcodes.SuccessCodes;
import com.hpmc.portal.pos.webservice.bean.PosDeviceDetails;

/**
 * @author Prakat-L-042
 *
 */
@Repository
public class PosDeviceDetailsDAOImpl implements PosDeviceDetailsDAO{

	private static final Logger logger = LogManager.getLogger(PosDeviceDetailsDAOImpl.class);	

	@Autowired
	private SessionFactory sessionFactory;


	/* 
	 * This method for search Pos Seraial number in db.
	 * retun true/false. 
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Boolean serachPosDevcieDetailsByPosNumber(String currentPosSerialNumber){
		logger.info("==>> Eneter into PosDeviceDetailsDAOImpl inside serachPosDevcieDetailsByPosNumber <<==START ::"+currentPosSerialNumber);
		Boolean isAvailable=false;
		try{
			Session session=sessionFactory.getCurrentSession();
			Criteria criteria=session.createCriteria(PosDeviceDetails.class);
			criteria.add(Restrictions.eq("posSerialNumber", currentPosSerialNumber));
			List<PosDeviceDetails> result=criteria.list();
			if (result != null&&result.size()!=0) {
				isAvailable=true;
			}
		} catch(Exception e){
			e.printStackTrace();
		}
		logger.info("==>> Eneter into PosDeviceDetailsDAOImpl inside serachPosDevcieDetailsByPosNumber <<==END ::"+isAvailable);
		return isAvailable;
	}


	/* (non-Javadoc)
	 * @see com.hpmc.portal.pos.webservice.dao.PosDeviceDetailsDAO#savePosDeviceDetailsBySerialNumber(com.hpmc.portal.pos.webservice.bean.PosDeviceDetails)
	 */
	@Override
	public BaseDTO savePosDeviceDetailsBySerialNumber(PosDeviceDetails posDeviceDetails){

		BaseDTO responseDTO=new BaseDTO();
		logger.info("==>> Eneter into PosDeviceDetailsDAOImpl inside savePosDeviceDetailsBySerialNumber <<==START ::"+posDeviceDetails);
		try{
			Session session = sessionFactory.getCurrentSession();
			session.saveOrUpdate(posDeviceDetails);
			responseDTO.setStatusCode(SuccessCodes.POS_DEVICE_DETAILS_SAVED.getCode());
			responseDTO.setMessage("Success");
			logger.info("==>> Pos device details saved successfully<<==");
		}catch(EntityExistsException  e){
			logger.error("From Entity");
			logger.error("==>> Error occured in PosDeviceDetailsServiceImpl inside savePosDeviceDetailsBySerialNumber <<=="+e.getMessage());

		}
		catch(ConstraintViolationException  c){
			logger.error("From cons");
			logger.error("==>> Error occured in PosDeviceDetailsServiceImpl inside savePosDeviceDetailsBySerialNumber <<=="+c.getMessage());
		}
		catch(DataIntegrityViolationException d){
			logger.error("From dataI");
			logger.error("==>> Error occured in PosDeviceDetailsServiceImpl inside savePosDeviceDetailsBySerialNumber <<=="+d.getMessage());
		}

		catch(Exception e){
			responseDTO.setStatusCode(ErrorCodes.INTERNAL_SERVER_ERROR.getCode());
			responseDTO.setMessage("Failure");
			logger.error("==>> Exception occured in PosDeviceDetailsDAOImpl inside savePosDeviceDetailsBySerialNumber <<== ::"+e.getMessage());
		}
		logger.info("==>> Enter into PosDeviceDetailsDAOImpl inside savePosDeviceDetailsBySerialNumber <<==END ::"+responseDTO);
		return responseDTO;
	}


	/**
	 * This method for count the no of PosCodeSeuence from DB. 
	 */
	@Override
	public Integer countNoOfPosCodeSeuence() {
		String query="select count(*) from PosDeviceDetails";
		Session session = sessionFactory.getCurrentSession();
		Integer noOfPosCodeSeuence=((Long)session.createQuery(query).uniqueResult()).intValue();
		return noOfPosCodeSeuence;
	}


	/**
	 * This method for find list of PosKeyStartRange from DB. 
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<Object> getListOfPosKeyStartRange(){
		Session session = sessionFactory.getCurrentSession();
		Criteria criteria=session.createCriteria(PosDeviceDetails.class);
		ProjectionList projList = Projections.projectionList();
		projList.add(Projections.property("posKeyRangeStart"));
		criteria.setProjection(projList);
		List<Object> li=criteria.list();
		return li;
	}


	/**
	 * This method for find list of PosKeyEndRange from DB. 
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<Object> getListOfPosKeyEndRange(){
		Session session = sessionFactory.getCurrentSession();
		Criteria criteria=session.createCriteria(PosDeviceDetails.class);
		ProjectionList projList = Projections.projectionList();
		projList.add(Projections.property("posKeyRangeEnd"));
		criteria.setProjection(projList);
		List<Object> li=criteria.list();
		return li;
	}

	public Boolean savePosSaleDetails(PosSaleDetails posSaleDetails){
		Boolean isSaved=false;
		try {
			Session currentSession = sessionFactory.getCurrentSession();
			Serializable serializableId=currentSession.save(posSaleDetails);
			if(serializableId!=null){
				isSaved=false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isSaved; 
	}

	public Boolean savePosSaleItemDetails(PosSaleItemDetails posSaleItemDetails){

		Boolean isSaved=false;
		try {
			Session currentSession = sessionFactory.getCurrentSession();
			Serializable serializableId=currentSession.save(posSaleItemDetails);
			if(serializableId!=null){
				isSaved=false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isSaved; 
	}


	@Override
	public Boolean savePosMisPurchaseOrderDetails(PosMisPurchaseOrderDetails posMisPurchaseOrderDetails) {

		Boolean isSaved=false;
		try {
			Session currentSession = sessionFactory.getCurrentSession();
			Serializable serializableId=currentSession.save(posMisPurchaseOrderDetails);
			if(serializableId!=null){
				isSaved=false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isSaved; 
	}






}
