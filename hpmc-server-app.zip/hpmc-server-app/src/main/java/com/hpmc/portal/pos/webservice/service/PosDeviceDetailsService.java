package com.hpmc.portal.pos.webservice.service;

import com.hmpc.dto.BaseDTO;

public interface PosDeviceDetailsService {
	public BaseDTO savePosDeviceDetailsBySerialNumber(String posSerialNumber);
	
	public BaseDTO savePosSaleDetailsCSVFiles();
	
	public BaseDTO savePosSaleItemDetailsCSVFiles();
	
	public BaseDTO savePosMisPurchaseOrderDetailsCSVFiles();

	

}
