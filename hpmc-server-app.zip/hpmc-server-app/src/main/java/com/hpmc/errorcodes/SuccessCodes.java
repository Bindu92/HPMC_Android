package com.hpmc.errorcodes;

public enum SuccessCodes {



//	SUCCESS(1000),
	

	FILE_SAVED_INTO_DB(1003),

	POS_DEVICE_DETAILS_SAVED(1002),

	FILE_SAVED_INTO_FOLDER(1004),




	;

	private Integer code;

	public Integer getCode() {
		return this.code;
	}

	private SuccessCodes(Integer code) {
		this.code = code;
	}

}
