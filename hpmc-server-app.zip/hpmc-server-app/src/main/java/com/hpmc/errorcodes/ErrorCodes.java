package com.hpmc.errorcodes;

/**
 * @author Prakat-L-042
 *
 */
public enum ErrorCodes {
	
	INTERNAL_SERVER_ERROR(2001),

	FILE_SAVED(2003),
	INVALID_FILE_PATH(2004),
	FOLDER_IS_EMPTY(2005),
	DIRECTORY_PATH_IS_INVALID(2006),
	
	
	POS_SERIAL_EXIST(2008),
	
	
	
	
	;

	private Integer code;

	public Integer getCode() {
		return this.code;
	}

	private ErrorCodes(Integer code) {
		this.code = code;
	}

}
