package com.hpmc.security;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.LinkedHashMap;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.IOUtils;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.hpmc.startapp.AuthTokenInfo;

public class SpringRestClient_DownloadByFileName {

	public static final String REST_SERVICE_URI = "http://localhost:7070/hpmc/";

	public static final String AUTH_SERVER_URI = "http://localhost:7070/hpmc/oauth/token";

	public static final String QPM_PASSWORD_GRANT = "?grant_type=password&username=hpmc_admin&password=HpmcAdmin121321456";

	public static final String QPM_ACCESS_TOKEN = "?access_token=";

	/*
	 * Prepare HTTP Headers.
	 */
	private static HttpHeaders getHeaders(){
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		return headers;
	}

	/*
	 * Add HTTP Authorization header, using Basic-Authentication to send client-credentials.
	 */
	private static HttpHeaders getHeadersWithClientCredentials(){
		String plainClientCredentials="my_trusted_client:my_trusted_secret";
		String base64ClientCredentials = new String(Base64.encodeBase64(plainClientCredentials.getBytes()));

		HttpHeaders headers = getHeaders();
		headers.add("Authorization", "Basic " + base64ClientCredentials);
		return headers;
	}    

	/*
	 * Send a POST request [on /oauth/token] to get an access-token, which will then be send with each request.
	 */
	@SuppressWarnings({ "unchecked"})
	private static AuthTokenInfo sendTokenRequest(){
		RestTemplate restTemplate = new RestTemplate(); 

		HttpEntity<String> request = new HttpEntity<String>(getHeadersWithClientCredentials());
		ResponseEntity<Object> response = restTemplate.exchange(AUTH_SERVER_URI+QPM_PASSWORD_GRANT, HttpMethod.POST, request, Object.class);
		LinkedHashMap<String, Object> map = (LinkedHashMap<String, Object>)response.getBody();
		AuthTokenInfo tokenInfo = null;

		if(map!=null){
			tokenInfo = new AuthTokenInfo();
			tokenInfo.setAccess_token((String)map.get("access_token"));
			tokenInfo.setToken_type((String)map.get("token_type"));
			tokenInfo.setRefresh_token((String)map.get("refresh_token"));
			tokenInfo.setExpires_in((int)map.get("expires_in"));
			tokenInfo.setScope((String)map.get("scope"));
			System.out.println(tokenInfo);




			//System.out.println("access_token ="+map.get("access_token")+", token_type="+map.get("token_type")+", refresh_token="+map.get("refresh_token")
			//+", expires_in="+map.get("expires_in")+", scope="+map.get("scope"));;
		}else{
			System.out.println("No user exist----------");

		}
		return tokenInfo;
	}


	/*
	 * Send a Pos  Device details...
	 */
	@SuppressWarnings("unused")
	private static void PosReg(AuthTokenInfo tokenInfo) {
		//    	Assert.notNull(tokenInfo, "Authenticate first please......");
		//        System.out.println("\nTesting all delete Users API----------");

		try {
			RestTemplate restTemplate = new RestTemplate();
			HttpEntity<String> request = new HttpEntity<String>(getHeaders());

			//            ResponseEntity<Resource> response=restTemplate.exchange(REST_SERVICE_URI+"/posDeviceDetails/savePosDeviceDetailsBySerialNumber/12GhuGG4"+QPM_ACCESS_TOKEN+tokenInfo.getAccess_token(),
			//            		HttpMethod.POST, request, Resource.class);
			String fileName = "hpmc_pos_farmer_details.csv";

			ResponseEntity<Resource> response=restTemplate.exchange(REST_SERVICE_URI+"/files/downloadFileByName/"+fileName+QPM_ACCESS_TOKEN+tokenInfo.getAccess_token(),
					HttpMethod.GET, request, Resource.class);

			if(response.getStatusCodeValue()==200){


				System.out.println(response);
				String directoryName ="C:\\Hpmc\\Poc\\";

				InputStream stream = response.getBody().getInputStream();
				byte[] byteArr = IOUtils.toByteArray(stream);
				Path path = Paths.get(directoryName + fileName);
				System.out.println(path);
				Files.write(path, byteArr);

			}
		}catch(Exception e){
			e.printStackTrace();
		}



		//            	
		//            	
		//            	
		//            	
		//            	System.out.println(response.getBody());
		//			String directoryName ="C:\\Hpmc\\Poc\\";
		//
		//        	String fileName = "abc.mp4";
		final AuthTokenInfo tokenInfo1 = sendTokenRequest();
		try {
			//        	File destination = new File(directoryName);
			//        	URL website = new URL(REST_SERVICE_URI + "/files/downloadFileByName/"+fileName+QPM_ACCESS_TOKEN + tokenInfo1.getAccess_token());
			//        	ReadableByteChannel rbc;
			//        	rbc = Channels.newChannel(website.openStream());
			//        	FileOutputStream fos = new FileOutputStream(destination);
			//        	fos.getChannel().transferFrom(rbc, 0, Long.MAX_VALUE);
			//        	fos.close();
			//        	rbc.close();
			//
			//        	System.out.println("file download done");
			//        	






		}catch(Exception e){
			e.printStackTrace();
		}

	}

	public static void main(String args[]){
//		AuthTokenInfo tokenInfo = sendTokenRequest();
//		    	PosReg(tokenInfo);

		uploadFile();
	}

	public static void uploadFile(){


		try {
			MultiValueMap<String, Object> bodyMap = new LinkedMultiValueMap<>();

						bodyMap.add("user-file", getUserFileResource());
//						bodyMap.add("user-file", getUserFileResource1());

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.MULTIPART_FORM_DATA);
			HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(bodyMap, headers);

			RestTemplate restTemplate = new RestTemplate();
			final AuthTokenInfo tokenInfo1 = sendTokenRequest();

			ResponseEntity<Resource> response=restTemplate.exchange(REST_SERVICE_URI+"/files/uploadFile/"+QPM_ACCESS_TOKEN+tokenInfo1.getAccess_token(),
					HttpMethod.POST, requestEntity, Resource.class);

//			ResponseEntity<BaseDTO> response = restTemplate.exchange("http://localhost:8082/saveFile",
//					HttpMethod.POST, requestEntity, BaseDTO.class);

			System.out.println("response status: " + response.getStatusCode());
			System.out.println("response body: " + response.getBody());

			


		}
		catch (ResourceAccessException e) {
			System.out.println("ResourceAccessException1");
			e.printStackTrace();
		} catch (Exception e) { 
			System.out.println("ResourceAccessException2");
			e.printStackTrace();
		}

	
	}


	public static Resource getUserFileResource() throws IOException {

//		File file = new File("C:\\Users\\Prakat-L-042\\Downloads\\hpmc_pos_sale_details_A.csv");
		File file = new File("C:\\Users\\Prakat-L-042\\Downloads\\hpmc_pos_farmer_details.csv");
		
		
		
		long fKB=file.length()/1024;
		System.out.println(fKB);
		
		long fMB=fKB/1024;
		System.out.println(fMB) ;
		
	
		return new FileSystemResource(file);
	}
	public static Resource getUserFileResource1() throws IOException {

		File file = new File("C:\\Users\\Prakat-L-042\\Downloads\\hpmc_pos_mis_purchase_order_details_A.csv");
		return new FileSystemResource(file);
	}
	
}