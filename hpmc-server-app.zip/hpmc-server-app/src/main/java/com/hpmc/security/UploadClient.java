package com.hpmc.security;

import java.io.File;
import java.io.IOException;

import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.hmpc.dto.BaseDTO;

public class UploadClient {

	public static void main(String[] args) throws IOException {
		for (int i = 0; i < 2; i++) {
			m();
		}
	}
	
	
	
	public static void m(){


		try {
			MultiValueMap<String, Object> bodyMap = new LinkedMultiValueMap<>();

						bodyMap.add("user-file", getUserFileResource());
						bodyMap.add("user-file", getUserFileResource1());

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.MULTIPART_FORM_DATA);
			HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(bodyMap, headers);

			RestTemplate restTemplate = new RestTemplate();

			ResponseEntity<BaseDTO> response = restTemplate.exchange("http://localhost:8082/saveFile",
					HttpMethod.POST, requestEntity, BaseDTO.class);

			System.out.println("response status: " + response.getStatusCode());
			System.out.println("response body: " + response.getBody());

			


		}
		catch (ResourceAccessException e) {
			System.out.println("ResourceAccessException1");
			e.printStackTrace();
		} catch (Exception e) { 
			System.out.println("ResourceAccessException2");
			e.printStackTrace();
		}

	
	}


	public static Resource getUserFileResource() throws IOException {

		File file = new File("C:\\Users\\Prakat-L-042\\Downloads\\hpmc_pos_sale_details_A.csv");
		
		long fKB=file.length()/1024;
		System.out.println(fKB);
		
		long fMB=fKB/1024;
		System.out.println(fMB) ;
		
	
		return new FileSystemResource(file);
	}
	public static Resource getUserFileResource1() throws IOException {

		File file = new File("C:\\Users\\Prakat-L-042\\Downloads\\hpmc_pos_mis_purchase_order_details_A.csv");
		return new FileSystemResource(file);
	}
	
	
	



}