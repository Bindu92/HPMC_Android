package com.hpmc.exception;

import com.hpmc.errorcodes.ErrorCodes;

/**
 * The Class RestException.
 */
public class RestException extends RuntimeException {

	/** The Constant serialVersionUID. */

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	/** The message. */
	private String message;

	private Integer statusCode;
	

	public RestException(ErrorCodes errorDescription) {
		this.statusCode = errorDescription.getCode();
	}



	public String getMessage() {
		return message;
	}



	public void setMessage(String message) {
		this.message = message;
	}



	public Integer getStatusCode() {
		return statusCode;
	}



	public void setStatusCode(Integer statusCode) {
		this.statusCode = statusCode;
	}

	@Override
	public String toString() {
		return "RestException [message=" + message + ", statusCode="
				+ statusCode + "]";
	}

}

