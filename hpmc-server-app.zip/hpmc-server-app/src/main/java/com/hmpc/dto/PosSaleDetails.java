package com.hmpc.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="hpmc_pos_sale_details")
public class PosSaleDetails implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="POS_SALE_ID")
	private Long PosSaleId;

	@Column(name="SHOP_ID")
	private Long shopId;

	@Column(name="SALE_TYPE")
	private String saleType;

	@Column(name="CUSTOMER_NAME")
	private String customerName;

	@Column(name="DATE")
	private Date date;

	@Column(name="SAP_STATUS")
	private Long sapStatus;


	public Long getPosSaleId() {
		return PosSaleId;
	}


	public void setPosSaleId(Long posSaleId) {
		PosSaleId = posSaleId;
	}


	public Long getShopId() {
		return shopId;
	}


	public void setShopId(Long shopId) {
		this.shopId = shopId;
	}


	public String getSaleType() {
		return saleType;
	}


	public void setSaleType(String saleType) {
		this.saleType = saleType;
	}


	public String getCustomerName() {
		return customerName;
	}


	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}


	public Date getDate() {
		return date;
	}


	public void setDate(Date date) {
		this.date = date;
	}


	public Long getSapStatus() {
		return sapStatus;
	}


	public void setSapStatus(Long sapStatus) {
		this.sapStatus = sapStatus;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((PosSaleId == null) ? 0 : PosSaleId.hashCode());
		result = prime * result
				+ ((customerName == null) ? 0 : customerName.hashCode());
		result = prime * result + ((date == null) ? 0 : date.hashCode());
		result = prime * result
				+ ((saleType == null) ? 0 : saleType.hashCode());
		result = prime * result
				+ ((sapStatus == null) ? 0 : sapStatus.hashCode());
		result = prime * result + ((shopId == null) ? 0 : shopId.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PosSaleDetails other = (PosSaleDetails) obj;
		if (PosSaleId == null) {
			if (other.PosSaleId != null)
				return false;
		} else if (!PosSaleId.equals(other.PosSaleId))
			return false;
		if (customerName == null) {
			if (other.customerName != null)
				return false;
		} else if (!customerName.equals(other.customerName))
			return false;
		if (date == null) {
			if (other.date != null)
				return false;
		} else if (!date.equals(other.date))
			return false;
		if (saleType == null) {
			if (other.saleType != null)
				return false;
		} else if (!saleType.equals(other.saleType))
			return false;
		if (sapStatus == null) {
			if (other.sapStatus != null)
				return false;
		} else if (!sapStatus.equals(other.sapStatus))
			return false;
		if (shopId == null) {
			if (other.shopId != null)
				return false;
		} else if (!shopId.equals(other.shopId))
			return false;
		return true;
	}


	@Override
	public String toString() {
		return "PosSaleDetails [PosSaleId=" + PosSaleId + ", shopId=" + shopId
				+ ", saleType=" + saleType + ", customerName=" + customerName
				+ ", date=" + date + ", sapStatus=" + sapStatus + "]";
	}

}
