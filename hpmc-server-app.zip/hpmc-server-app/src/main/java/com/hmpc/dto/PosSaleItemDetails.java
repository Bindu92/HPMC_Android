package com.hmpc.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="hpmc_pos_sale_item_details")
public class PosSaleItemDetails implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="POS_SALE_ITEM_ID")
	private Long posSaleItemId;

	@Column(name="POS_SALE_ID")
	private Long posSaleId;

	@Column(name="SALE_ITEM_ID")
	private Long saleItemId;

	@Column(name="QUANTITY")
	private Long quantity;

	@Column(name="UNIT_OF_MEASUREMENT")
	private String unitOfMeasurement;

	@Column(name="CGST_AMOUNT")
	private Double cgstAmount;

	@Column(name="SGST_AMOUNT")
	private Double sgstAmount;

	@Column(name="TOTAL_AMOUNT")
	private Double totalAmount;

	@Column(name="SAP_STATUS")
	private Long sapStatus;

	public Long getPosSaleItemId() {
		return posSaleItemId;
	}

	public void setPosSaleItemId(Long posSaleItemId) {
		this.posSaleItemId = posSaleItemId;
	}

	public Long getPosSaleId() {
		return posSaleId;
	}

	public void setPosSaleId(Long posSaleId) {
		this.posSaleId = posSaleId;
	}

	public Long getSaleItemId() {
		return saleItemId;
	}

	public void setSaleItemId(Long saleItemId) {
		this.saleItemId = saleItemId;
	}

	public Long getQuantity() {
		return quantity;
	}

	public void setQuantity(Long quantity) {
		this.quantity = quantity;
	}

	public String getUnitOfMeasurement() {
		return unitOfMeasurement;
	}

	public void setUnitOfMeasurement(String unitOfMeasurement) {
		this.unitOfMeasurement = unitOfMeasurement;
	}

	public Double getCgstAmount() {
		return cgstAmount;
	}

	public void setCgstAmount(Double cgstAmount) {
		this.cgstAmount = cgstAmount;
	}

	public Double getSgstAmount() {
		return sgstAmount;
	}

	public void setSgstAmount(Double sgstAmount) {
		this.sgstAmount = sgstAmount;
	}

	public Double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public Long getSapStatus() {
		return sapStatus;
	}

	public void setSapStatus(Long sapStatus) {
		this.sapStatus = sapStatus;
	}
	
	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((cgstAmount == null) ? 0 : cgstAmount.hashCode());
		result = prime * result
				+ ((posSaleId == null) ? 0 : posSaleId.hashCode());
		result = prime * result
				+ ((posSaleItemId == null) ? 0 : posSaleItemId.hashCode());
		result = prime * result
				+ ((quantity == null) ? 0 : quantity.hashCode());
		result = prime * result
				+ ((saleItemId == null) ? 0 : saleItemId.hashCode());
		result = prime * result
				+ ((sapStatus == null) ? 0 : sapStatus.hashCode());
		result = prime * result
				+ ((sgstAmount == null) ? 0 : sgstAmount.hashCode());
		result = prime * result
				+ ((totalAmount == null) ? 0 : totalAmount.hashCode());
		result = prime
				* result
				+ ((unitOfMeasurement == null) ? 0 : unitOfMeasurement
						.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PosSaleItemDetails other = (PosSaleItemDetails) obj;
		if (cgstAmount == null) {
			if (other.cgstAmount != null)
				return false;
		} else if (!cgstAmount.equals(other.cgstAmount))
			return false;
		if (posSaleId == null) {
			if (other.posSaleId != null)
				return false;
		} else if (!posSaleId.equals(other.posSaleId))
			return false;
		if (posSaleItemId == null) {
			if (other.posSaleItemId != null)
				return false;
		} else if (!posSaleItemId.equals(other.posSaleItemId))
			return false;
		if (quantity == null) {
			if (other.quantity != null)
				return false;
		} else if (!quantity.equals(other.quantity))
			return false;
		if (saleItemId == null) {
			if (other.saleItemId != null)
				return false;
		} else if (!saleItemId.equals(other.saleItemId))
			return false;
		if (sapStatus == null) {
			if (other.sapStatus != null)
				return false;
		} else if (!sapStatus.equals(other.sapStatus))
			return false;
		if (sgstAmount == null) {
			if (other.sgstAmount != null)
				return false;
		} else if (!sgstAmount.equals(other.sgstAmount))
			return false;
		if (totalAmount == null) {
			if (other.totalAmount != null)
				return false;
		} else if (!totalAmount.equals(other.totalAmount))
			return false;
		if (unitOfMeasurement == null) {
			if (other.unitOfMeasurement != null)
				return false;
		} else if (!unitOfMeasurement.equals(other.unitOfMeasurement))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "PosSaleItemDetails [posSaleItemId=" + posSaleItemId
				+ ", posSaleId=" + posSaleId + ", saleItemId=" + saleItemId
				+ ", quantity=" + quantity + ", unitOfMeasurement="
				+ unitOfMeasurement + ", cgstAmount=" + cgstAmount
				+ ", sgstAmount=" + sgstAmount + ", totalAmount=" + totalAmount
				+ ", sapStatus=" + sapStatus + "]";
	}




}
