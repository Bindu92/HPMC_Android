package com.hmpc.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="hpmc_pos_mis_purchase_order_details")
public class PosMisPurchaseOrderDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="PURCHASE_ORDER_ID")
	private Long purchaseOrderId;

	@Column(name="GR_SLIP_NO")
	private String grSlipNo;

	@Column(name="VENDOR_CODE")
	private Long vendorCode;

	@Column(name="PURCHASE_ORDER_NO")
	private Long purchaseOrderNo;

	@Column(name="LINE_ITEM")
	private Long lineItem;

	@Column(name="PLANT_CODE")
	private String plantCode;

	@Column(name="STORAGE_LOCATION")
	private String storageLocation;

	@Column(name="NET_WEIGHT")
	private Double netWeight;

	@Column(name="GROSS_WEIGHT")
	private Double grossWeight;

	@Column(name="RECEIVED_NUM_OF_BAG")
	private Long receivedNumOfBag;

	@Column(name="TOTAL_AMOUNT")
	private Double totalAmount;

	@Column(name="RECEIPT_DATE")
	private Date receiptDate;

	@Column(name="SAP_STATUS")
	private Long sapStatus;



	public Long getPurchaseOrderId() {
		return purchaseOrderId;
	}



	public void setPurchaseOrderId(Long purchaseOrderId) {
		this.purchaseOrderId = purchaseOrderId;
	}



	public String getGrSlipNo() {
		return grSlipNo;
	}



	public void setGrSlipNo(String grSlipNo) {
		this.grSlipNo = grSlipNo;
	}



	public Long getVendorCode() {
		return vendorCode;
	}



	public void setVendorCode(Long vendorCode) {
		this.vendorCode = vendorCode;
	}



	public Long getPurchaseOrderNo() {
		return purchaseOrderNo;
	}



	public void setPurchaseOrderNo(Long purchaseOrderNo) {
		this.purchaseOrderNo = purchaseOrderNo;
	}



	public Long getLineItem() {
		return lineItem;
	}



	public void setLineItem(Long lineItem) {
		this.lineItem = lineItem;
	}

	public String getPlantCode() {
		return plantCode;
	}



	public void setPlantCode(String plantCode) {
		this.plantCode = plantCode;
	}



	public String getStorageLocation() {
		return storageLocation;
	}



	public void setStorageLocation(String storageLocation) {
		this.storageLocation = storageLocation;
	}



	public Double getNetWeight() {
		return netWeight;
	}



	public void setNetWeight(Double netWeight) {
		this.netWeight = netWeight;
	}



	public Double getGrossWeight() {
		return grossWeight;
	}



	public void setGrossWeight(Double grossWeight) {
		this.grossWeight = grossWeight;
	}



	public Long getReceivedNumOfBag() {
		return receivedNumOfBag;
	}



	public void setReceivedNumOfBag(Long receivedNumOfBag) {
		this.receivedNumOfBag = receivedNumOfBag;
	}



	public Double getTotalAmount() {
		return totalAmount;
	}



	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}



	public Date getReceiptDate() {
		return receiptDate;
	}



	public void setReceiptDate(Date receiptDate) {
		this.receiptDate = receiptDate;
	}



	public Long getSapStatus() {
		return sapStatus;
	}



	public void setSapStatus(Long sapStatus) {
		this.sapStatus = sapStatus;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((grSlipNo == null) ? 0 : grSlipNo.hashCode());
		result = prime * result
				+ ((grossWeight == null) ? 0 : grossWeight.hashCode());
		result = prime * result
				+ ((lineItem == null) ? 0 : lineItem.hashCode());
		result = prime * result
				+ ((netWeight == null) ? 0 : netWeight.hashCode());
		result = prime * result
				+ ((plantCode == null) ? 0 : plantCode.hashCode());
		result = prime * result
				+ ((purchaseOrderId == null) ? 0 : purchaseOrderId.hashCode());
		result = prime * result
				+ ((purchaseOrderNo == null) ? 0 : purchaseOrderNo.hashCode());
		result = prime * result
				+ ((receiptDate == null) ? 0 : receiptDate.hashCode());
		result = prime
				* result
				+ ((receivedNumOfBag == null) ? 0 : receivedNumOfBag.hashCode());
		result = prime * result
				+ ((sapStatus == null) ? 0 : sapStatus.hashCode());
		result = prime * result
				+ ((storageLocation == null) ? 0 : storageLocation.hashCode());
		result = prime * result
				+ ((totalAmount == null) ? 0 : totalAmount.hashCode());
		result = prime * result
				+ ((vendorCode == null) ? 0 : vendorCode.hashCode());
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PosMisPurchaseOrderDetails other = (PosMisPurchaseOrderDetails) obj;
		if (grSlipNo == null) {
			if (other.grSlipNo != null)
				return false;
		} else if (!grSlipNo.equals(other.grSlipNo))
			return false;
		if (grossWeight == null) {
			if (other.grossWeight != null)
				return false;
		} else if (!grossWeight.equals(other.grossWeight))
			return false;
		if (lineItem == null) {
			if (other.lineItem != null)
				return false;
		} else if (!lineItem.equals(other.lineItem))
			return false;
		if (netWeight == null) {
			if (other.netWeight != null)
				return false;
		} else if (!netWeight.equals(other.netWeight))
			return false;
		if (plantCode == null) {
			if (other.plantCode != null)
				return false;
		} else if (!plantCode.equals(other.plantCode))
			return false;
		if (purchaseOrderId == null) {
			if (other.purchaseOrderId != null)
				return false;
		} else if (!purchaseOrderId.equals(other.purchaseOrderId))
			return false;
		if (purchaseOrderNo == null) {
			if (other.purchaseOrderNo != null)
				return false;
		} else if (!purchaseOrderNo.equals(other.purchaseOrderNo))
			return false;
		if (receiptDate == null) {
			if (other.receiptDate != null)
				return false;
		} else if (!receiptDate.equals(other.receiptDate))
			return false;
		if (receivedNumOfBag == null) {
			if (other.receivedNumOfBag != null)
				return false;
		} else if (!receivedNumOfBag.equals(other.receivedNumOfBag))
			return false;
		if (sapStatus == null) {
			if (other.sapStatus != null)
				return false;
		} else if (!sapStatus.equals(other.sapStatus))
			return false;
		if (storageLocation == null) {
			if (other.storageLocation != null)
				return false;
		} else if (!storageLocation.equals(other.storageLocation))
			return false;
		if (totalAmount == null) {
			if (other.totalAmount != null)
				return false;
		} else if (!totalAmount.equals(other.totalAmount))
			return false;
		if (vendorCode == null) {
			if (other.vendorCode != null)
				return false;
		} else if (!vendorCode.equals(other.vendorCode))
			return false;
		return true;
	}



	@Override
	public String toString() {
		return "PosMisPurchaseOrderDetails [purchaseOrderId=" + purchaseOrderId
				+ ", grSlipNo=" + grSlipNo + ", vendorCode=" + vendorCode
				+ ", purchaseOrderNo=" + purchaseOrderNo + ", lineItem="
				+ lineItem + ", plantCode=" + plantCode + ", storageLocation="
				+ storageLocation + ", netWeight=" + netWeight
				+ ", grossWeight=" + grossWeight + ", receivedNumOfBag="
				+ receivedNumOfBag + ", totalAmount=" + totalAmount
				+ ", receiptDate=" + receiptDate + ", sapStatus=" + sapStatus
				+ "]";
	}



}
