package com.hmpc.dto;

import java.io.Serializable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * @author Prakat-L-042
 *
 */
public class BaseDTO implements Serializable {	

	private static final long serialVersionUID = 1L;

	public static TreeMap<Integer, String> treeMapErrorsDetails=new TreeMap<>();

	
	static{
		treeMapErrorsDetails.put(1000,"Success");
		treeMapErrorsDetails.put(2001,"Internal server error occured, please try aagin after some time.");
		
		treeMapErrorsDetails.put(2002,"File can't be empty.");
		treeMapErrorsDetails.put(1001,"File saved into Database.");
		treeMapErrorsDetails.put(1004,"File uploaded into folder.");
		
		
		treeMapErrorsDetails.put(2007,"Pos device details not saved.");
		treeMapErrorsDetails.put(1002,"Pos device details registered successfully.");
		treeMapErrorsDetails.put(2008,"This pos device number is already registered.");


		treeMapErrorsDetails.put(2004,"Given file path sequence is invalid.");
		treeMapErrorsDetails.put(2005,"Folder is empty.");
		treeMapErrorsDetails.put(2006,"Directory path is invalid.");


	}

	/** error code. 0 if success else unique error code value */
	Integer statusCode = 2000;

	String message;

	String description;

	int totalRecords;

	Object responseContent;

	List<?> responseContents;

	Map<?,?> responseContentsMap;


	public void setStatusCode(Integer statusCode) {
		this.statusCode = statusCode;

		Iterator<?> itr=treeMapErrorsDetails.entrySet().iterator();

		while(itr.hasNext()){
			@SuppressWarnings("unchecked")
			Map.Entry<Integer, String> ent=(Map.Entry<Integer, String>)itr.next();
			Integer i=ent.getKey();
			if(this.statusCode.equals(i)){
				String currentDescription=ent.getValue();
				this.description=currentDescription;
				break;
			}
		}
	}


	public static TreeMap<Integer, String> getTreeMapErrorsDetails() {
		return treeMapErrorsDetails;
	}


	public static void setTreeMapErrorsDetails(
			TreeMap<Integer, String> treeMapErrorsDetails) {
		BaseDTO.treeMapErrorsDetails = treeMapErrorsDetails;
	}


	public String getMessage() {
		return message;
	}


	public void setMessage(String message) {
		this.message = message;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public int getTotalRecords() {
		return totalRecords;
	}


	public void setTotalRecords(int totalRecords) {
		this.totalRecords = totalRecords;
	}


	public Object getResponseContent() {
		return responseContent;
	}


	public void setResponseContent(Object responseContent) {
		this.responseContent = responseContent;
	}


	public List<?> getResponseContents() {
		return responseContents;
	}


	public void setResponseContents(List<?> responseContents) {
		this.responseContents = responseContents;
	}


	public Map<?, ?> getResponseContentsMap() {
		return responseContentsMap;
	}


	public void setResponseContentsMap(Map<?, ?> responseContentsMap) {
		this.responseContentsMap = responseContentsMap;
	}


	public Integer getStatusCode() {
		return statusCode;
	}


	@Override
	public String toString() {
		return "BaseDTO [statusCode=" + statusCode + ", message=" + message
				+ ", description=" + description + "]";
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((description == null) ? 0 : description.hashCode());
		result = prime * result + ((message == null) ? 0 : message.hashCode());
		result = prime * result
				+ ((responseContent == null) ? 0 : responseContent.hashCode());
		result = prime
				* result
				+ ((responseContents == null) ? 0 : responseContents.hashCode());
		result = prime
				* result
				+ ((responseContentsMap == null) ? 0 : responseContentsMap
						.hashCode());
		result = prime * result
				+ ((statusCode == null) ? 0 : statusCode.hashCode());
		result = prime * result + totalRecords;
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BaseDTO other = (BaseDTO) obj;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (message == null) {
			if (other.message != null)
				return false;
		} else if (!message.equals(other.message))
			return false;
		if (responseContent == null) {
			if (other.responseContent != null)
				return false;
		} else if (!responseContent.equals(other.responseContent))
			return false;
		if (responseContents == null) {
			if (other.responseContents != null)
				return false;
		} else if (!responseContents.equals(other.responseContents))
			return false;
		if (responseContentsMap == null) {
			if (other.responseContentsMap != null)
				return false;
		} else if (!responseContentsMap.equals(other.responseContentsMap))
			return false;
		if (statusCode == null) {
			if (other.statusCode != null)
				return false;
		} else if (!statusCode.equals(other.statusCode))
			return false;
		if (totalRecords != other.totalRecords)
			return false;
		return true;
	}
	
	
	
	
	
	

}