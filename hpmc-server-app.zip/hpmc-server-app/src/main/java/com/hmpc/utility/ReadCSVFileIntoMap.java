package com.hmpc.utility;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

@Component
public class ReadCSVFileIntoMap {
	
	private static final Logger logger = LogManager.getLogger(ReadCSVFileIntoMap.class);	

	
	/**
	 * This method will read csv file data and store into {@link LinkedHashMap}
	 * @param currentFile
	 * @return {@link LinkedHashMap}
	 */
	public LinkedHashMap<Integer,ArrayList<String>> readCSVFile(File currentFile){
		LinkedHashMap<Integer,ArrayList<String>> csvFileMap=new LinkedHashMap<Integer, ArrayList<String>>();
		int noOfColumns=1;
		FileReader fileReader=null;
		BufferedReader bufferedReader = null;
		try {
			fileReader=new FileReader(currentFile);    
			bufferedReader = new BufferedReader(fileReader);
			String line = bufferedReader.readLine();

			while (line!= null) {
				String newLine[]=line.split(",");

				if(newLine.length!=0){
					ArrayList<String> listOfWords=new ArrayList<String>();
					for (String string : newLine) {
						listOfWords.add(string);
					}
					csvFileMap.put(noOfColumns, listOfWords);
					noOfColumns++;
				}
				line = bufferedReader.readLine();

			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}catch (IOException e) {
			e.printStackTrace();
		}finally {
			try {
				if (bufferedReader != null)
					bufferedReader.close();
				if (fileReader != null)
					fileReader.close();
			} catch (IOException ex) {
				logger.error("==>> Exception occured inside writeDataIntoCSVFile <<===");
			}
		}
		if(currentFile.delete()){
			System.out.println("Deleted");
		}

		return csvFileMap;

	}

}
