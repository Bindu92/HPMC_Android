package com.hmpc.files.service;

import java.io.File;
import java.util.List;

import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;

import com.hmpc.dto.BaseDTO;
public interface FileService {

	public BaseDTO saveFilesIntoDirectory(List<MultipartFile> multipartFile);
	
	public BaseDTO loadFileNames();

	public Resource loadFileAsResourceByFileName(String fileName);
	
	public BaseDTO saveFileIntoDB(File file);
	
	
}
