
package com.hmpc.files.service;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.hmpc.dto.BaseDTO;
import com.hmpc.utility.ReadCSVFileIntoMap;
import com.hpmc.errorcodes.ErrorCodes;
import com.hpmc.errorcodes.SuccessCodes;
import com.hpmc.exception.MyFileNotFoundException;
import com.hpmc.exception.RestException;


/**
 * This class for file handling
 * @author Prakat-L-042
 *
 */
@Service
public class FileServiceImpl implements FileService{

	private static final Logger logger = LogManager.getLogger(FileServiceImpl.class);	

	private static final String UPLOAD_FILES_INTO_KIOSK_SALES_SHOP_DIRECORY="C:\\HPMC_POS_Files\\Upload\\KIOSK Sales Shop\\";
	private static final String UPLOAD_FILES_INTO_MIS_PURCHASE_DIRECORY="C:\\HPMC_POS_Files\\Upload\\MIS Purchase\\";

	private static final String DOWNLOAD_FILES_DIRECTORY="C:\\HPMC_POS_Files\\Download\\";


	@Autowired
	ReadCSVFileIntoMap csvFileIntoMap;


	/**
	 * This method for saving file into the directory
	 * @param multipartFiles
	 * @return {@link BaseDTO}
	 */
	public BaseDTO saveFilesIntoDirectory(List<MultipartFile> multipartFiles) {

		logger.info("==>> Enter into FileServiceImpl inside saveFilesIntoDirectory <<===Start"+ multipartFiles.size());
		BaseDTO baseDTO=new BaseDTO();

		for (MultipartFile multipartFile : multipartFiles) {
			String fileName = StringUtils.cleanPath(multipartFile.getOriginalFilename());

			if(fileName.contains("hpmc_pos_sale_")){
				baseDTO=saveFilesIntoKIOSKSalesShopDirectory(multipartFile);
			}
			if(fileName.contains("hpmc_pos_mis_purchase_order_details_")){
				baseDTO=saveFilesIntoMISPurchaseDirectory(multipartFile);
			}

		}


		logger.info("==>> Enter into FileServiceImpl inside saveFilesIntoDirectory <<===End"+baseDTO);
		return baseDTO;       
	}

	private BaseDTO saveFilesIntoMISPurchaseDirectory(MultipartFile multipartFile) {

		BaseDTO baseDTO=new BaseDTO();
		try {
			logger.info("==>> Enter into FileServiceImpl inside saveFilesIntoMISPurchaseDirectory <<===Start"+ multipartFile.getName());
			String fileName = StringUtils.cleanPath(multipartFile.getOriginalFilename());

			if(fileName.contains("..")) {
				logger.warn("==>> Given file path sequence is invalid. <<=="+fileName);
				throw new RestException(ErrorCodes.INVALID_FILE_PATH);
			}
			File isFileAvailable = new File(UPLOAD_FILES_INTO_MIS_PURCHASE_DIRECORY+fileName);

			if(isFileAvailable.exists()){

				//Convert MultipartFile into File
				File currentFile=convertMultipartFileToFile(multipartFile);

				//read the csv file data into Map
				LinkedHashMap<Integer,ArrayList<String>> csvFileMap=csvFileIntoMap.readCSVFile(currentFile);

				//write data into csv file
				Boolean iswriteen=writeIntoMISPurchaseDirecory(csvFileMap,fileName);
				if(iswriteen){
					logger.info("==>> Files saved Successfully <<===");
					baseDTO.setStatusCode(SuccessCodes.FILE_SAVED_INTO_FOLDER.getCode());
					baseDTO.setMessage("Success");
				}else{
					baseDTO.setStatusCode(ErrorCodes.INTERNAL_SERVER_ERROR.getCode());
					baseDTO.setMessage("Failure");
					logger.info("==>> Files not saved <<===");
				}

			}else{
				String directoryName =UPLOAD_FILES_INTO_MIS_PURCHASE_DIRECORY.concat(fileName);
				Path targetLocation =Paths.get(directoryName);
				Files.copy(multipartFile.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);
				logger.info("==>> Files saved Successfully <<===");
				baseDTO.setStatusCode(SuccessCodes.FILE_SAVED_INTO_FOLDER.getCode());
				baseDTO.setMessage("Success");
			}
		} catch (RestException e) {
			baseDTO.setStatusCode(e.getStatusCode());
			baseDTO.setMessage("Failure");
			logger.warn("==>>Error occured inside <<=="+baseDTO.getDescription());
		}catch(IOException e){
			baseDTO.setStatusCode(ErrorCodes.INTERNAL_SERVER_ERROR.getCode());
			baseDTO.setMessage("Failure");
			logger.error("===>> Exception occured while saving file <<==="+e.getMessage());
		}
		catch(Exception e){
			baseDTO.setStatusCode(ErrorCodes.INTERNAL_SERVER_ERROR.getCode());
			baseDTO.setMessage("Failure");
			logger.error("===>> Exception occured while saving file <<==="+e.getMessage());
		}
		logger.info("==>> Enter into FileServiceImpl inside saveFilesIntoMISPurchaseDirectory <<===End ::"+ baseDTO);
		return baseDTO;		
	}

	private BaseDTO saveFilesIntoKIOSKSalesShopDirectory(MultipartFile multipartFile) {
		BaseDTO baseDTO=new BaseDTO();
		try {
			logger.info("==>> Enter into FileServiceImpl inside saveFilesIntoKIOSKSalesShopDirectory <<===Start ::"+ multipartFile.getName());

			String fileName = StringUtils.cleanPath(multipartFile.getOriginalFilename());

			if(fileName.contains("..")) {
				logger.warn("==>> Given file path sequence is invalid. <<=="+fileName);
				throw new RestException(ErrorCodes.INVALID_FILE_PATH);
			}
			File isFileAvailable = new File(UPLOAD_FILES_INTO_KIOSK_SALES_SHOP_DIRECORY+fileName);

			if(isFileAvailable.exists()){

				//Convert MultipartFile into File
				File currentFile=convertMultipartFileToFile(multipartFile);

				//read the csv file data into Map
				LinkedHashMap<Integer,ArrayList<String>> csvFileMap=csvFileIntoMap.readCSVFile(currentFile);

				//write data into csv file
				Boolean iswriteen=writeIntoCSVFileIntoKIOSKSalesShopDirecory(csvFileMap,fileName);
				if(iswriteen){
					logger.info("==>> Files saved Successfully <<===");
					baseDTO.setStatusCode(SuccessCodes.FILE_SAVED_INTO_FOLDER.getCode());
					baseDTO.setMessage("Success");
				}else{
					baseDTO.setStatusCode(ErrorCodes.INTERNAL_SERVER_ERROR.getCode());
					baseDTO.setMessage("Failure");
					logger.info("==>> Files not saved <<===");
				}

			}else{
				String directoryName =UPLOAD_FILES_INTO_KIOSK_SALES_SHOP_DIRECORY.concat(fileName);
				Path targetLocation =Paths.get(directoryName);
				Files.copy(multipartFile.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);
				logger.info("==>> Files saved Successfully <<===");
				baseDTO.setStatusCode(SuccessCodes.FILE_SAVED_INTO_FOLDER.getCode());
				baseDTO.setMessage("Success");
			}
		} catch (RestException e) {
			baseDTO.setStatusCode(e.getStatusCode());
			baseDTO.setMessage("Failure");
			logger.warn("==>>Error occured inside <<=="+baseDTO.getDescription());
		}catch(IOException e){
			baseDTO.setStatusCode(ErrorCodes.INTERNAL_SERVER_ERROR.getCode());
			baseDTO.setMessage("Failure");
			logger.error("===>> Exception occured while saving file <<==="+e.getMessage());
		}
		catch(Exception e){
			baseDTO.setStatusCode(ErrorCodes.INTERNAL_SERVER_ERROR.getCode());
			baseDTO.setMessage("Failure");
			logger.error("===>> Exception occured while saving file <<==="+e.getMessage());
		}
		logger.info("==>> Enter into FileServiceImpl inside saveFilesIntoKIOSKSalesShopDirectory <<===End ::"+ baseDTO);
		return baseDTO;		
	}

	public static File convertMultipartFileToFile(MultipartFile file)
	{    		   
		logger.info("==>>Enter into FileServiceImpl inside convert<<==Start"+file.getOriginalFilename());
		File convFile = new File(file.getOriginalFilename());
		BufferedReader bufferedReader=null;
		try {
			convFile.createNewFile(); 
			FileOutputStream fos = new FileOutputStream(convFile); 
			fos.write(file.getBytes());
			fos.close();
			bufferedReader=new BufferedReader(new FileReader(convFile));
			String newLine=bufferedReader.readLine();
			while(newLine!=null){
				newLine=bufferedReader.readLine();
			}

		} catch (Exception e) {
			logger.error("==>>Exception occured inside convert<<=="+e.getMessage());
		}finally {
			try {
				if (bufferedReader != null)
					bufferedReader.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		logger.info("==>>Enter into FileServiceImpl inside convert<<==End");
		return convFile;

	}

	/* This method for loadAllFile names from the directory
	 * @see com.hmpc.files.service.FileService#loadFileNames()
	 * @return {@link BaseDTO}
	 */
	@Override
	public BaseDTO loadFileNames() {
		logger.info("==>> Enter into FileServiceImpl inside loadFileNames <<===Start");

		BaseDTO baseDTO=new BaseDTO();
		try {
			//			String directoryName ="C:/Users/Prakat-L-042/Desktop/HPMC-3/HPMC_REST_APPLICATION/Hpmc-Rest-Application/uploads";
			ArrayList<String> fileNames=new ArrayList<String>();
			Integer noOfFiles=0;
			File[] files=new File(DOWNLOAD_FILES_DIRECTORY).listFiles();
			if(files==null){
				logger.warn("==>> Given directory path is invalid<<==");
				throw new RestException(ErrorCodes.DIRECTORY_PATH_IS_INVALID);
			}
			for (File file : files) {
				if (file.isFile()) {
					String fileName=file.getName();
					fileNames.add(fileName);
					noOfFiles++;
				}
			}
			if(noOfFiles==0){
				logger.warn("==>> Files not found in the folder<<==");
				throw new RestException(ErrorCodes.FOLDER_IS_EMPTY);	
			}else{
				baseDTO.setResponseContents(fileNames);
				baseDTO.setTotalRecords(noOfFiles);
				baseDTO.setMessage("Success");
				logger.info("==>> Files names loaded successfully <<==");
			}
		} catch (RestException e) {
			System.out.println(e.getStatusCode());
			baseDTO.setStatusCode(e.getStatusCode());
			baseDTO.setMessage("Failure");
			logger.warn("==>>Error occured  <<=="+baseDTO.getDescription());
		}catch(Exception e){
			baseDTO.setStatusCode(ErrorCodes.INTERNAL_SERVER_ERROR.getCode());
			baseDTO.setMessage("Failure");
			logger.error("===>> Exception occured while loading file <<==="+e.getMessage());
		}
		logger.info("==>> Enter into FileServiceImpl inside loadFileNames <<===End"+baseDTO);
		return baseDTO;
	}

	/* This method for load file as a Resource class from the directory based ob file name
	 * @see com.hmpc.files.service.FileService#loadFileAsResource(java.lang.String)
	 */
	public Resource loadFileAsResourceByFileName(String fileName) throws MyFileNotFoundException  {
		logger.info("==>> Enter into FileServiceImpl inside downkiadFileByFileName<<==Start"+fileName);

		try {

			String textPath=DOWNLOAD_FILES_DIRECTORY.concat(fileName);
			Path filePath = Paths.get(textPath);
			Resource resource = new UrlResource(filePath.toUri());
			if(resource.exists()) {
				logger.info("==>> Enter into FileServiceImpl inside downkiadFileByFileName<<==End");
				return resource;
			} else {
				logger.warn("==>> File is not found <<==");
				throw new MyFileNotFoundException("File not found " + fileName);
			}
		} catch (MalformedURLException ex) {
			logger.warn("==>> File is not found <<==");
			throw new MyFileNotFoundException("File not found " + fileName, ex);
		}catch (Exception e) {
			logger.error("===>> Exception occured while loading file <<==="+e.getMessage());
			throw new MyFileNotFoundException("File not found " + fileName);
		}
	}

	

	/**
	 * @param csvFileMap
	 * @param fileName
	 * @return {@link Boolean}
	 */
	public static Boolean  writeIntoCSVFileIntoKIOSKSalesShopDirecory(LinkedHashMap<Integer, ArrayList<String>> csvFileMap, String fileName){	
		Boolean  isAvailable=false;
		Iterator<Entry<Integer, ArrayList<String>>> itr = csvFileMap.entrySet().iterator();
		BufferedWriter bw = null;
		FileWriter fw = null;
		File file = new File(UPLOAD_FILES_INTO_KIOSK_SALES_SHOP_DIRECORY+fileName);
		try {
			fw = new FileWriter(file.getAbsoluteFile(), true);
			bw = new BufferedWriter(fw);
			while(itr.hasNext()){
				ArrayList<String> al=new ArrayList<String>();
				Entry<Integer, ArrayList<String>> entry = itr.next();
				al.addAll(entry.getValue());
				for (String string : al) {
					try{
						if (!file.exists()) {
							file.createNewFile();
						}
						bw.write(string);
						bw.write(",");
						isAvailable=true;

					}catch(IOException e){
						logger.error("==>> Exception occured inside writeDataIntoCSVFile <<==="+e.getMessage());
						isAvailable=false;
					}
				}
				bw.write("\n");
			}
		} catch (IOException e1) {
			e1.printStackTrace();
		}finally {
			try {
				if (bw != null)
					bw.close();
				if (fw != null)
					fw.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		return isAvailable;
	}


	public static Boolean  writeIntoMISPurchaseDirecory(LinkedHashMap<Integer, ArrayList<String>> csvFileMap, String fileName){	
		Boolean  isAvailable=false;
		Iterator<Entry<Integer, ArrayList<String>>> itr = csvFileMap.entrySet().iterator();
		BufferedWriter bw = null;
		FileWriter fw = null;
		File file = new File(UPLOAD_FILES_INTO_MIS_PURCHASE_DIRECORY+fileName);
		try {
			fw = new FileWriter(file.getAbsoluteFile(), true);
			bw = new BufferedWriter(fw);
			while(itr.hasNext()){
				ArrayList<String> al=new ArrayList<String>();
				Entry<Integer, ArrayList<String>> entry = itr.next();
				al.addAll(entry.getValue());
				for (String string : al) {
					try{
						if (!file.exists()) {
							file.createNewFile();
						}
						bw.write(string);
						bw.write(",");
						isAvailable=true;

					}catch(IOException e){
						logger.error("==>> Exception occured inside writeDataIntoCSVFile <<==="+e.getMessage());
						isAvailable=false;
					}
				}
				bw.write("\n");
			}
		} catch (IOException e1) {
			e1.printStackTrace();
		}finally {
			try {
				if (bw != null)
					bw.close();
				if (fw != null)
					fw.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		return isAvailable;
	}

	public BaseDTO saveFileIntoDB(File file){
		BaseDTO responseDTO=new BaseDTO();


		return responseDTO;
	}

}